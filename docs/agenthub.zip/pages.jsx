// AgentHub page bodies — Dashboard, Marketplace, Detail, Init, Approvals, Governance

const { I, Pill, Tag, Avatar, Card, Spark } = window;
const { KPIS, FEATURED_SKILLS, ALL_SKILLS, SKILL_CATEGORIES, RECENT_RUNS, APPROVAL_QUEUE, PIPELINE_FEED, DOMAIN_TREE } = window.AGENTHUB_DATA;

const SPARKS = {
  users:  [120,140,135,160,180,195,210,205,232,240,255,260,288,310],
  skus:   [180,182,185,190,196,201,205,210,218,221,228,234,240,248],
  pulls:  [800,920,1100,1050,1300,1450,1600,1720,1900,2080,2200,2350,2510,2700],
  ai:    [42,45,48,50,52,55,58,60,61,62,64,65,66,67],
};
const SPARK_KEYS = ['users','skus','pulls','ai'];

// ============================================================== DASHBOARD
function DashboardPage({ go }) {
  return (
    <div className="page page-dashboard">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">研发辅助 · 工作台</div>
          <h1>欢迎回来，陈思源</h1>
          <p className="page-sub">海康集团 AgentHub · 私有化部署 · 平台工程组</p>
        </div>
        <div className="hero-actions">
          <button className="btn btn-ghost" onClick={() => go('marketplace')}>{I.store}<span>浏览技能广场</span></button>
        </div>
      </header>

      <div className="kpi-row">
        {KPIS.map((k, i) => (
          <div key={k.label} className="kpi">
            <div className="kpi-meta">
              <div className="kpi-label">{k.label}</div>
              <div className={`kpi-delta ${k.trend}`}>{k.delta}</div>
            </div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-sub">{k.sub}</div>
            <Spark data={SPARKS[SPARK_KEYS[i]]} accent={i === 0 ? 'var(--accent)' : i === 1 ? '#0E7C66' : i === 2 ? '#3461C1' : '#B8730C'}/>
          </div>
        ))}
      </div>

      <div className="grid-2-1">
        <Card title="精选 SKU · 研发辅助" action={<button className="link" onClick={() => go('marketplace')}>查看全部 →</button>}>
          <div className="featured-grid">
            {FEATURED_SKILLS.map(s => (
              <button key={s.id} className={`featured-card accent-${s.accent}`} onClick={() => go('detail', s.id)}>
                <div className="fc-top">
                  <Avatar name={s.avatar} tone={s.accent}/>
                  <div className="fc-meta">
                    <div className="fc-title">{s.title}</div>
                    <div className="fc-sub">{s.author} · v{s.version}</div>
                  </div>
                  <Pill tone={s.channel === 'stable' ? 'success' : 'amber'} dot>{s.channel}</Pill>
                </div>
                <p className="fc-desc">{s.desc}</p>
                <div className="fc-bottom">
                  <div className="fc-tags">{s.tags.slice(0,3).map(t => <Tag key={t}>{t}</Tag>)}</div>
                  <div className="fc-stats">
                    <span>{I.download}<b>{s.pulls.toLocaleString()}</b></span>
                    <span className="star">{I.star}<b>{s.rating}</b></span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <Card title="流水线实时反馈">
          <ul className="feed">
            {PIPELINE_FEED.map((f, i) => (
              <li key={i} className={`feed-${f.kind}`}>
                <span className="feed-time">{f.t}</span>
                <span className="feed-dot"/>
                <span className="feed-text">{f.text}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="grid-1-1">
        <Card title="最近 SKU 调用" action={<span className="hint">最近 24 小时</span>}>
          <table className="table">
            <thead><tr><th>SKU</th><th>项目</th><th>使用者</th><th>时间</th><th>耗时</th><th>结果</th></tr></thead>
            <tbody>
              {RECENT_RUNS.map(r => (
                <tr key={r.id}>
                  <td><code>{r.skill}</code></td>
                  <td>{r.project}</td>
                  <td><span className="user-cell"><span className="dot-avatar">{r.user[0]}</span>{r.user}</span></td>
                  <td className="muted">{r.ts}</td>
                  <td className="muted">{r.dur}</td>
                  <td>
                    {r.result === 'success' && <Pill tone="success" dot>通过</Pill>}
                    {r.result === 'blocked' && <Pill tone="danger" dot>被拦截</Pill>}
                    {r.result === 'warn' && <Pill tone="amber" dot>有警告</Pill>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card title="待我处理" action={<button className="link" onClick={() => go('approvals')}>进入审批 →</button>}>
          <ul className="approval-list">
            {APPROVAL_QUEUE.map(a => (
              <li key={a.id} className="approval-item">
                <div className="ai-main">
                  <div className="ai-title"><code>{a.skill}</code> <span className="muted">v{a.version}</span></div>
                  <div className="ai-sub">{a.author} · {a.age}</div>
                </div>
                <div className="ai-side">
                  <Pill tone={a.risk === 'high' ? 'danger' : a.risk === 'medium' ? 'amber' : 'neutral'} dot>风险 {a.risk}</Pill>
                  <Pill tone="info">{a.stage}</Pill>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

// ============================================================== MARKETPLACE
function MarketplacePage({ go }) {
  const [cat, setCat] = React.useState('all');
  const [q, setQ] = React.useState('');
  const [sort, setSort] = React.useState('hot');
  const skills = ALL_SKILLS.filter(s => {
    if (q && !(`${s.title}${s.name}${s.desc}`.toLowerCase().includes(q.toLowerCase()))) return false;
    return true;
  }).sort((a,b) => sort === 'hot' ? b.pulls - a.pulls : sort === 'new' ? a.id.localeCompare(b.id) : b.rating - a.rating);

  return (
    <div className="page page-market">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">技能广场 / Skill Marketplace</div>
          <h1>面向研发的私有 SKU 目录</h1>
          <p className="page-sub">发现、订阅、热更新经组织审批的可复用研发能力包</p>
        </div>
        <div className="hero-actions">
          <button className="btn btn-ghost">{I.book}<span>发布手册</span></button>
          <button className="btn btn-primary" onClick={() => go('publish')}>{I.rocket}<span>发布我的 SKU</span></button>
        </div>
      </header>

      <div className="market-toolbar">
        <div className="search">
          {I.search}
          <input placeholder="搜索 SKU 名称、关键词、业务域 …" value={q} onChange={e => setQ(e.target.value)} />
          <kbd>⌘ K</kbd>
        </div>
        <div className="sort">
          {[['hot','最热'],['new','最新'],['rating','评分']].map(([k,v]) => (
            <button key={k} className={sort === k ? 'on' : ''} onClick={() => setSort(k)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="market-layout">
        <aside className="market-side">
          <div className="side-section">
            <div className="side-title">分类</div>
            <ul className="side-list">
              {SKILL_CATEGORIES.map(c => (
                <li key={c.id}><button className={cat === c.id ? 'on' : ''} onClick={() => setCat(c.id)}><span>{c.label}</span><span className="ct">{c.count}</span></button></li>
              ))}
            </ul>
          </div>
          <div className="side-section">
            <div className="side-title">业务域</div>
            <ul className="side-list">
              {DOMAIN_TREE.map(d => (
                <li key={d.id}><button><span>{d.label}</span><span className="ct">{d.count}</span></button></li>
              ))}
            </ul>
          </div>
          <div className="side-section">
            <div className="side-title">发布通道</div>
            <div className="chip-row">
              <span className="chip on">stable</span>
              <span className="chip">latest</span>
              <span className="chip">beta</span>
              <span className="chip">deprecated</span>
            </div>
          </div>
          <div className="side-section">
            <div className="side-title">质量等级</div>
            <div className="chip-row">
              <span className="chip">L1</span>
              <span className="chip on">L2</span>
              <span className="chip on">L3</span>
            </div>
          </div>
        </aside>

        <div className="market-main">
          <div className="result-bar">
            <div>共 <b>{skills.length}</b> 个 SKU · 已应用 <b>{cat === 'all' ? '全部' : SKILL_CATEGORIES.find(x=>x.id===cat)?.label}</b></div>
            <div className="muted">私有 marketplace · git://platform/claude-marketplace</div>
          </div>
          <div className="sku-grid">
            {skills.map(s => (
              <button key={s.id} className={`sku-card accent-${s.accent}`} onClick={() => go('detail', s.id)}>
                <div className="sk-head">
                  <Avatar name={s.avatar} tone={s.accent}/>
                  <div className="sk-text">
                    <div className="sk-name"><code>{s.name}</code></div>
                    <div className="sk-title">{s.title}</div>
                  </div>
                  <Pill tone={s.channel === 'stable' ? 'success' : 'amber'} dot>{s.channel}</Pill>
                </div>
                <p className="sk-desc">{s.desc}</p>
                <div className="sk-meta">
                  <span>{s.runtime}</span>
                  <span className="dot">·</span>
                  <span>{s.domain}</span>
                  <span className="dot">·</span>
                  <span>v{s.version}</span>
                </div>
                <div className="sk-bottom">
                  <div className="sk-tags">{s.tags.map(t => <Tag key={t}>{t}</Tag>)}</div>
                  <div className="sk-stats">
                    <span>{I.download}<b>{s.pulls.toLocaleString()}</b></span>
                    <span className="star">{I.star}<b>{s.rating}</b></span>
                    <Pill tone="neutral">{s.qualityGate}</Pill>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================== DETAIL
function DetailPage({ id, go }) {
  const s = ALL_SKILLS.find(x => x.id === id) || ALL_SKILLS[0];
  const [tab, setTab] = React.useState('readme');
  return (
    <div className="page page-detail">
      <div className="crumbs">
        <button onClick={() => go('marketplace')}>技能广场</button>
        <span>/</span>
        <span>{s.domain}</span>
        <span>/</span>
        <b>{s.name}</b>
      </div>

      <header className={`detail-hero accent-${s.accent}`}>
        <div className="dh-left">
          <Avatar name={s.avatar} tone={s.accent}/>
          <div>
            <div className="dh-name"><code>{s.name}</code> <span className="dh-ver">v{s.version}</span></div>
            <h1>{s.title}</h1>
            <p>{s.desc}</p>
            <div className="dh-meta">
              <Pill tone={s.channel === 'stable' ? 'success' : 'amber'} dot>{s.channel}</Pill>
              <Pill tone="info">{s.skuType}</Pill>
              <Pill tone="neutral">{s.domain}</Pill>
              <Pill tone="neutral">质量等级 {s.qualityGate}</Pill>
              <Pill tone="success" dot>{s.approval}</Pill>
            </div>
          </div>
        </div>
        <div className="dh-right">
          <div className="dh-stats">
            <div><b>{s.pulls.toLocaleString()}</b><span>本月拉取</span></div>
            <div><b>{s.rating}</b><span>研发评分</span></div>
            <div><b>32</b><span>依赖项目</span></div>
          </div>
          <div className="dh-actions">
            <button className="btn btn-primary">{I.plug}<span>启用至当前项目</span></button>
            <button className="btn btn-ghost">{I.copy}<span>复制安装命令</span></button>
          </div>
        </div>
      </header>

      <div className="install-box">
        <div className="install-label">在你的项目根目录执行</div>
        <code className="install-code">
          <span className="cmt"># 已配置 extraKnownMarketplaces · 团队成员信任目录后将自动提示安装</span>
          {'\n'}<span className="prompt">$</span> claude plugin add <span className="hl">{s.name}@platform-marketplace</span> --version {s.version}
        </code>
      </div>

      <div className="tabs">
        {[['readme','使用说明'],['skills','技能 / Skills'],['hooks','Hooks'],['versions','版本历史'],['compat','兼容矩阵'],['govern','治理与审计']].map(([k,v]) => (
          <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{v}</button>
        ))}
      </div>

      <div className="grid-2-1">
        <div className="detail-main">
          {tab === 'readme' && (
            <Card>
              <h2 className="md-h2">概览</h2>
              <p>本 SKU 面向「{s.domain}」业务，封装了集团 Java 微服务工程的标准脚手架、OpenAPI 约束、ArchUnit 边界、Pact 契约与 Harness 流水线模板。</p>
              <h2 className="md-h2">提供能力</h2>
              <ul className="md-list">
                <li><b>bootstrap-service</b> — 一键生成 Maven Archetype 化的服务骨架，注入 .claude 基线与 Harness 模板</li>
                <li><b>generate-controller</b> — 基于实体反推 Controller / Service / Mapper / DTO，遵循集团接口命名与错误码规范</li>
                <li><b>generate-openapi</b> — 构建期通过 springdoc 生成文档，叠加 Spectral 风格 lint</li>
                <li><b>self-test</b> — 一键运行单测、ArchUnit、OpenAPI、Checkstyle、SpotBugs 与安全扫描</li>
              </ul>
              <h2 className="md-h2">使用条件</h2>
              <p>仅限 <code>Java 21 + Spring Boot 3.3</code>；若项目运行时不满足，将由 Setup Hook 输出兼容性提示而非自动降级。</p>
              <pre className="codebox">
{`---
name: self-test
description: 为当前 Java 微服务执行本地自测
disable-model-invocation: true
allowed-tools: Bash(mvn test *) Bash(mvn verify *) Read Grep
---
1. 运行单测与集成测试
2. 运行 ArchUnit 规则
3. 生成并校验 OpenAPI 文档
4. 运行 Checkstyle / SpotBugs / 安全规则
5. 输出失败定位与可复制命令`}
              </pre>
            </Card>
          )}
          {tab === 'skills' && (
            <Card>
              <table className="table">
                <thead><tr><th>Skill</th><th>触发条件</th><th>权限</th><th>负责人</th></tr></thead>
                <tbody>
                  <tr><td><code>bootstrap-service</code></td><td>新建空仓库</td><td>Write Bash(mvn *)</td><td>陈思源</td></tr>
                  <tr><td><code>generate-controller</code></td><td>检测到 @Entity</td><td>Edit Read</td><td>苏彦</td></tr>
                  <tr><td><code>generate-openapi</code></td><td>maven verify 阶段</td><td>Bash Read</td><td>周禾</td></tr>
                  <tr><td><code>self-test</code></td><td>显式调用</td><td>Bash Read Grep</td><td>陈思源</td></tr>
                </tbody>
              </table>
            </Card>
          )}
          {tab === 'hooks' && (
            <Card>
              <ul className="hook-list">
                <li><Pill tone="info">Setup</Pill><span>扫描项目结构、生成 Skill Draft、推荐相关插件</span></li>
                <li><Pill tone="info">PreEdit</Pill><span>对生成代码注入 ArchUnit 边界检查与错误码字典</span></li>
                <li><Pill tone="amber">PrePR</Pill><span>调用 Harness STO，对 Critical 漏洞拦截</span></li>
              </ul>
            </Card>
          )}
          {tab === 'versions' && (
            <Card pad={false}>
              <table className="table">
                <thead><tr><th>版本</th><th>通道</th><th>发布时间</th><th>变更摘要</th><th>状态</th></tr></thead>
                <tbody>
                  <tr><td><code>1.3.0</code></td><td><Pill tone="success" dot>stable</Pill></td><td>2026-04-28</td><td>Spring Boot 3.3 升级 · 新增 OpenAPI 异常映射</td><td><Pill tone="success">当前</Pill></td></tr>
                  <tr><td><code>1.2.4</code></td><td><Pill tone="success" dot>stable</Pill></td><td>2026-03-12</td><td>修复 Mapper 模板生成 Lombok 注解错乱</td><td>历史</td></tr>
                  <tr><td><code>1.2.0</code></td><td><Pill tone="amber" dot>latest</Pill></td><td>2026-02-01</td><td>引入 ArchUnit 基线规则</td><td>历史</td></tr>
                  <tr><td><code>1.0.0</code></td><td><Pill tone="success" dot>stable</Pill></td><td>2025-11-08</td><td>首个稳定版本</td><td>历史</td></tr>
                </tbody>
              </table>
            </Card>
          )}
          {tab === 'compat' && (
            <Card>
              <table className="table">
                <thead><tr><th>组件</th><th>版本要求</th><th>测试覆盖</th></tr></thead>
                <tbody>
                  <tr><td>Claude Code</td><td>≥ 2.1.98</td><td><Pill tone="success" dot>已通过</Pill></td></tr>
                  <tr><td>JDK</td><td>21 (LTS)</td><td><Pill tone="success" dot>已通过</Pill></td></tr>
                  <tr><td>Spring Boot</td><td>3.3.x</td><td><Pill tone="success" dot>已通过</Pill></td></tr>
                  <tr><td>Spring Boot</td><td>3.2.x</td><td><Pill tone="amber" dot>降级支持</Pill></td></tr>
                  <tr><td>Harness CI</td><td>2024.10+</td><td><Pill tone="success" dot>已通过</Pill></td></tr>
                </tbody>
              </table>
            </Card>
          )}
          {tab === 'govern' && (
            <Card>
              <ul className="govern-list">
                <li><b>数据分类</b><span>内部</span></li>
                <li><b>数据驻留</b><span>仅集团私有 LLM Gateway · 不外发</span></li>
                <li><b>OPA 策略</b><span>禁止移除 ArchUnit 测试 / 禁止 0.0.0.0 监听</span></li>
                <li><b>审计接收</b><span>OpenTelemetry → 集团 SOC</span></li>
                <li><b>责任团队</b><span>Platform Engineering</span></li>
              </ul>
            </Card>
          )}
        </div>

        <aside className="detail-side">
          <Card title="依赖关系">
            <ul className="dep-list">
              <li><Pill tone="success" dot>必须</Pill><code>security-baseline ~2.1.0</code></li>
              <li><Pill tone="info">可选</Pill><code>harness-pipeline-template ^3.2</code></li>
              <li><Pill tone="info">可选</Pill><code>archunit-baseline-rules ^1.4</code></li>
            </ul>
          </Card>
          <Card title="使用此 SKU 的项目">
            <ul className="proj-list">
              <li><span className="dot-avatar dot-blue">OF</span><div><b>order-fulfillment-svc</b><span className="muted">订单中心 · 32 名研发</span></div></li>
              <li><span className="dot-avatar dot-teal">BL</span><div><b>billing-api</b><span className="muted">商业化平台 · 18 名研发</span></div></li>
              <li><span className="dot-avatar dot-amber">PR</span><div><b>partner-portal-bff</b><span className="muted">伙伴生态 · 11 名研发</span></div></li>
              <li><span className="dot-avatar dot-red">VS</span><div><b>vms-recording-svc</b><span className="muted">视频管理 · 24 名研发</span></div></li>
            </ul>
          </Card>
          <Card title="维护者">
            <div className="owner">
              <Avatar name="PE" tone="primary"/>
              <div>
                <b>Platform Engineering</b>
                <span className="muted">陈思源 · 苏彦 · 周禾</span>
              </div>
            </div>
          </Card>
        </aside>
      </div>
    </div>
  );
}

// ============================================================== INIT WIZARD
function InitPage({ go }) {
  const [step, setStep] = React.useState(2);
  const [topology, setTopology] = React.useState('crud');
  const [domain, setDomain] = React.useState('order');
  const [name, setName] = React.useState('order-fulfillment-svc');

  const TOPOS = [
    { id: 'crud', title: '标准 CRUD API', desc: 'Spring Boot · OpenAPI · MySQL · Redis 缓存', skus: 6 },
    { id: 'event', title: '事件消费者', desc: 'Kafka · Schema Registry · 幂等表 · 重放', skus: 5 },
    { id: 'bff', title: '对外 BFF', desc: 'GraphQL 网关 · 鉴权聚合 · 灰度路由', skus: 7 },
    { id: 'iot', title: 'IoT 视频流接入', desc: 'Netty · RTSP · GB28181 · 设备影子', skus: 8 },
  ];

  const DOMAINS = [
    { id: 'order', label: '订单域' }, { id: 'video-iot', label: '视频物联' },
    { id: 'billing', label: '商业化' }, { id: 'security', label: '安全合规' },
    { id: 'platform', label: '平台底座' },
  ];

  const recommendedSkus = topology === 'crud'
    ? ['java-order-service-sku','security-baseline','harness-pipeline-template','archunit-baseline-rules','pact-contract-test','errcode-knowledge-base']
    : ['iot-stream-bootstrap','security-baseline','harness-pipeline-template','archunit-baseline-rules','video-algo-helper'];

  return (
    <div className="page page-init">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">脚手架向导</div>
          <h1>初始化新服务</h1>
          <p className="page-sub">PoC → 试点 → 全量推广 全链路体验：四步从空仓库到通过质量门禁</p>
        </div>
      </header>

      <div className="stepper">
        {['选择拓扑','基本信息','推荐 SKU','质量门禁'].map((s,i) => (
          <div key={s} className={`step ${step >= i ? 'on' : ''} ${step === i ? 'now' : ''}`}>
            <span className="step-num">{i+1}</span>
            <span className="step-label">{s}</span>
            {i < 3 && <span className="step-line"/>}
          </div>
        ))}
      </div>

      <div className="grid-2-1">
        <div className="init-main">
          <Card title="① 选择服务拓扑">
            <div className="topo-grid">
              {TOPOS.map(t => (
                <button key={t.id} className={`topo ${topology === t.id ? 'on' : ''}`} onClick={() => setTopology(t.id)}>
                  <div className="topo-title">{t.title}</div>
                  <div className="topo-desc">{t.desc}</div>
                  <div className="topo-meta"><Pill tone="info">推荐 {t.skus} 个 SKU</Pill></div>
                </button>
              ))}
            </div>
          </Card>

          <Card title="② 基本信息">
            <div className="form-row">
              <label>服务名</label>
              <input className="input" value={name} onChange={e => setName(e.target.value)}/>
              <span className="hint">将作为 Maven artifactId · git 仓库名 · Harness 服务名</span>
            </div>
            <div className="form-row">
              <label>所属业务域</label>
              <div className="seg">
                {DOMAINS.map(d => <button key={d.id} className={domain === d.id ? 'on' : ''} onClick={() => setDomain(d.id)}>{d.label}</button>)}
              </div>
            </div>
            <div className="form-row">
              <label>JDK 基线</label>
              <div className="seg">
                <button className="on">Java 21 (推荐)</button>
                <button>Java 17</button>
                <button>Java 11</button>
              </div>
            </div>
            <div className="form-row">
              <label>发布通道默认</label>
              <div className="seg">
                <button className="on">stable</button>
                <button>latest</button>
              </div>
            </div>
          </Card>

          <Card title="③ 推荐 SKU 集" action={<span className="hint">基于拓扑 · 业务域 · 集团强制基线综合</span>}>
            <ul className="reco-list">
              {recommendedSkus.map(id => {
                const s = ALL_SKILLS.find(x => x.id.startsWith(id) || x.name === id) || { name: id, title: id, accent: 'primary', avatar: id.slice(0,2).toUpperCase(), version: '1.0.0', desc: '集团基线 SKU', approval: '强制启用' };
                const forced = s.approval === '强制启用';
                return (
                  <li key={id} className="reco-item">
                    <Avatar name={s.avatar} tone={s.accent}/>
                    <div className="reco-text">
                      <b><code>{s.name || id}</code> <span className="muted">v{s.version}</span></b>
                      <span className="muted">{s.title}</span>
                    </div>
                    <div className="reco-side">
                      {forced && <Pill tone="danger" dot>强制启用</Pill>}
                      <label className="switch"><input type="checkbox" defaultChecked disabled={forced}/><span/></label>
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>

          <Card title="④ 预生成产物预览" action={<span className="hint">Setup Hook 将在团队成员信任目录后写入</span>}>
            <pre className="codebox tree">
{`${name}/
├── .claude/
│   └── settings.json            # extraKnownMarketplaces / enabledPlugins
├── .claude-plugin/
├── pom.xml                       # Spring Boot 3.3 + springdoc + ArchUnit + Pact
├── harness/
│   └── pipeline.yml              # Build → Test → Lint → STO → OPA → Deploy
├── src/main/java/.../
├── src/test/java/.../arch/       # ArchUnit 基线
├── src/test/java/.../contract/   # Pact 契约
└── README.md`}
            </pre>
          </Card>
        </div>

        <aside className="init-side">
          <Card title="本次初始化摘要">
            <ul className="summary">
              <li><span>拓扑</span><b>{TOPOS.find(t => t.id === topology).title}</b></li>
              <li><span>业务域</span><b>{DOMAINS.find(d => d.id === domain).label}</b></li>
              <li><span>JDK</span><b>Java 21</b></li>
              <li><span>SKU 数量</span><b>{recommendedSkus.length}</b></li>
              <li><span>强制基线</span><b>2 个</b></li>
              <li><span>Harness 模板</span><b>java-microservice-v3</b></li>
            </ul>
            <button className="btn btn-primary btn-block" onClick={() => go('dashboard')}>{I.rocket}<span>生成项目并提交首个 PR</span></button>
            <button className="btn btn-ghost btn-block">{I.copy}<span>仅复制 .claude 配置</span></button>
          </Card>
          <Card title="预计耗时">
            <div className="big-stat"><b>4'12"</b><span>从空仓库到首个 PR</span></div>
            <div className="muted small">同类项目历史均值 9'05"，AI 平均节省 54%。</div>
          </Card>
        </aside>
      </div>
    </div>
  );
}

// ============================================================== APPROVALS
function ApprovalsPage() {
  return (
    <div className="page page-approvals">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">发布与审批</div>
          <h1>SKU 发布管线</h1>
          <p className="page-sub">作者发布 → 域负责人评审 → 平台发布器生成 marketplace → 上线</p>
        </div>
      </header>

      <div className="kanban">
        {[
          { title: '草稿', tone: 'neutral', items: [
            { name: 'partner-data-sync', author: '苏彦', age: '今日'},
            { name: 'edge-codec-shim', author: '林沐', age: '今日'},
          ]},
          { title: '域评审', tone: 'info', items: [
            { name: 'video-algo-helper', author: '许岚 · AI Lab', age: '2 天', risk: 'medium'},
            { name: 'rtsp-mock-recorder', author: '林沐 · IoT', age: '4 天', risk: 'high'},
          ]},
          { title: '平台发布', tone: 'amber', items: [
            { name: 'errcode-knowledge-base', author: '陈思源 · Platform Eng', age: '5h', risk: 'low'},
          ]},
          { title: '已上线', tone: 'success', items: [
            { name: 'java-order-service-sku v1.3.0', author: 'Platform Eng', age: '本周'},
            { name: 'pact-contract-test v1.0.6', author: 'QA Platform', age: '本周'},
          ]},
        ].map(col => (
          <div key={col.title} className={`kcol kcol-${col.tone}`}>
            <header className="kcol-head"><h3>{col.title}</h3><span className="ct">{col.items.length}</span></header>
            <div className="kcol-body">
              {col.items.map(it => (
                <div key={it.name} className="kcard">
                  <div className="kcard-name"><code>{it.name}</code></div>
                  <div className="kcard-meta">{it.author} · {it.age}</div>
                  {it.risk && <Pill tone={it.risk === 'high' ? 'danger' : it.risk === 'medium' ? 'amber' : 'success'} dot>风险 {it.risk}</Pill>}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <Card title="质量门禁配置" action={<span className="hint">由 Harness Policy as Code 强制</span>}>
        <table className="table">
          <thead><tr><th>检查项</th><th>等级</th><th>阻断条件</th><th>当前状态</th></tr></thead>
          <tbody>
            <tr><td>OpenAPI 风格 Lint (Spectral)</td><td>L1</td><td>error 级问题 ≥ 1</td><td><Pill tone="success" dot>启用</Pill></td></tr>
            <tr><td>ArchUnit 架构边界</td><td>L2</td><td>失败用例 ≥ 1</td><td><Pill tone="success" dot>启用</Pill></td></tr>
            <tr><td>Pact 契约测试</td><td>L2</td><td>不兼容变更 ≥ 1</td><td><Pill tone="success" dot>启用</Pill></td></tr>
            <tr><td>STO 安全扫描</td><td>L3</td><td>新增 Critical / High</td><td><Pill tone="success" dot>启用</Pill></td></tr>
            <tr><td>OPA 策略 (集团基线)</td><td>L3</td><td>禁止移除强制 SKU</td><td><Pill tone="success" dot>启用</Pill></td></tr>
            <tr><td>OpenTelemetry 审计落库</td><td>L3</td><td>未上报视为失败</td><td><Pill tone="amber" dot>试运行</Pill></td></tr>
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ============================================================== GOVERNANCE
function GovernancePage() {
  const bars = [
    ['平台底座', 36, 0.92], ['视频物联', 41, 0.88], ['订单域', 28, 0.81], ['AI 实验', 19, 0.62], ['安全合规', 16, 0.95], ['边缘计算', 12, 0.74],
  ];
  return (
    <div className="page page-gov">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">治理与分析</div>
          <h1>组织级 SKU 健康度</h1>
          <p className="page-sub">以业务域为视角衡量复用率、活跃度、合规率与废弃节奏</p>
        </div>
      </header>

      <div className="kpi-row">
        {[
          { label: '组织 SKU 总量', value: '248', sub: 'stable 156 · beta 64 · deprecated 28' },
          { label: '本月有效复用率', value: '63.4%', sub: '复用 SKU / 新增 SKU' },
          { label: 'Critical 漏洞拦截', value: '47', sub: '本月新增，由 STO 阻断' },
          { label: '未审批发布', value: '0', sub: '集团 OPA 策略已收口' },
        ].map(k => (
          <div key={k.label} className="kpi kpi-flat">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-sub">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid-2-1">
        <Card title="业务域 SKU 健康度">
          <div className="bar-list">
            {bars.map(([name, count, health]) => (
              <div className="bar-row" key={name}>
                <div className="bar-label">{name}<span className="muted"> · {count} SKU</span></div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${(health*100).toFixed(0)}%`, background: health > 0.85 ? 'var(--success)' : health > 0.7 ? 'var(--amber)' : 'var(--danger)' }}/>
                </div>
                <div className="bar-val">{(health*100).toFixed(0)}%</div>
              </div>
            ))}
          </div>
        </Card>
        <Card title="集团 Managed Settings">
          <ul className="ms-list">
            <li><b>strictKnownMarketplaces</b><span>仅信任 platform-marketplace</span><Pill tone="success" dot>开</Pill></li>
            <li><b>allowManagedHooksOnly</b><span>禁止用户级未知 hook 注入</span><Pill tone="success" dot>开</Pill></li>
            <li><b>enabledPlugins (默认)</b><span>security-baseline, harness-pipeline-template</span><Pill tone="success" dot>开</Pill></li>
            <li><b>LLM Gateway</b><span>集团网关 · Bedrock + Vertex 双通道</span><Pill tone="info">混合</Pill></li>
            <li><b>Zero Data Retention</b><span>研发代码不出集团域</span><Pill tone="amber" dot>条件启用</Pill></li>
          </ul>
        </Card>
      </div>

      <Card title="审计事件流" action={<span className="hint">最近 1 小时 · 已对接集团 SOC</span>}>
        <table className="table">
          <thead><tr><th>时间</th><th>事件</th><th>主体</th><th>对象</th><th>策略</th></tr></thead>
          <tbody>
            <tr><td className="muted">14:02:31</td><td><Pill tone="success" dot>install</Pill></td><td>陈思源</td><td><code>java-order-service-sku@1.3.0</code></td><td>strictKnownMarketplaces</td></tr>
            <tr><td className="muted">14:00:15</td><td><Pill tone="danger" dot>block</Pill></td><td>iot-gateway-edge CI</td><td><code>OPA: forbid-cidr-0.0.0.0</code></td><td>strict-policy-baseline</td></tr>
            <tr><td className="muted">13:55:08</td><td><Pill tone="success" dot>publish</Pill></td><td>QA Platform</td><td><code>pact-contract-test@1.0.6</code></td><td>approval-by-domain</td></tr>
            <tr><td className="muted">13:48:42</td><td><Pill tone="amber" dot>warn</Pill></td><td>vms-recording-svc</td><td><code>archunit: layer-violation</code></td><td>archunit-baseline</td></tr>
            <tr><td className="muted">13:32:11</td><td><Pill tone="success" dot>release</Pill></td><td>Platform Eng</td><td><code>java-order-service-sku@1.3.0</code></td><td>two-channel (stable+latest)</td></tr>
          </tbody>
        </table>
      </Card>
    </div>
  );
}

Object.assign(window, { DashboardPage, MarketplacePage, DetailPage, InitPage, ApprovalsPage, GovernancePage });
