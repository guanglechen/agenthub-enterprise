// AgentHub main shell — sidebar nav + topbar + page router

const { I, Pill, Tag, Avatar } = window;
const { DashboardPage, MarketplacePage, DetailPage, InitPage, ApprovalsPage, GovernancePage } = window;
const { TweaksPanel, useTweaks, TweakSection, TweakColor, TweakRadio, TweakToggle } = window;

const NAV = [
  { id: 'dashboard', label: '工作台', icon: I.grid, group: '研发' },
  { id: 'marketplace', label: '技能广场', icon: I.store, group: '研发' },
  { id: 'docs', label: '使用手册', icon: I.book, group: '资源' },
  { id: 'settings', label: '组织设置', icon: I.cog, group: '资源' },
];

const PALETTES = {
  hikRed:    { '--accent': '#D7000F', '--accent-deep': '#A8000C', '--accent-soft': '#FCEBEC' },
  carbon:    { '--accent': '#1F2A3D', '--accent-deep': '#0E1B33', '--accent-soft': '#E6E9EF' },
  sapphire:  { '--accent': '#1E5BD0', '--accent-deep': '#163F8F', '--accent-soft': '#E6EEFB' },
  emerald:   { '--accent': '#0E7C66', '--accent-deep': '#0A5C4C', '--accent-soft': '#E2F2EE' },
};

function App() {
  const [route, setRoute] = React.useState({ page: 'dashboard', id: null });
  const [t, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "palette": "hikRed",
    "density": "comfortable",
    "showSidebarLabels": true,
    "useDarkTopbar": true
  }/*EDITMODE-END*/);

  const go = React.useCallback((page, id = null) => setRoute({ page, id }), []);

  // Apply palette as CSS vars
  const paletteVars = PALETTES[t.palette] || PALETTES.hikRed;

  const grouped = {};
  NAV.forEach(n => { (grouped[n.group] = grouped[n.group] || []).push(n); });

  return (
    <div className={`app density-${t.density} ${t.useDarkTopbar ? 'dark-topbar' : ''}`} style={paletteVars}>
      <aside className={`sidebar ${t.showSidebarLabels ? '' : 'compact'}`}>
        <div className="brand">
          <div className="brand-mark">
            <svg viewBox="0 0 32 32" fill="none">
              <rect x="2" y="2" width="28" height="28" rx="7" fill="var(--accent)"/>
              <path d="M9 10v12M9 16h7M16 10v12M23 10v12" stroke="#fff" strokeWidth="2.4" strokeLinecap="round"/>
              <circle cx="23" cy="22" r="2" fill="#fff"/>
            </svg>
          </div>
          <div className="brand-text">
            <b>AgentHub</b>
            <span>研发辅助 · 私有化</span>
          </div>
        </div>

        <nav className="nav">
          {Object.entries(grouped).map(([g, items]) => (
            <div className="nav-group" key={g}>
              <div className="nav-group-label">{g}</div>
              {items.map(n => (
                <button key={n.id} className={`nav-item ${route.page === n.id ? 'on' : ''}`} onClick={() => go(n.id)}>
                  <span className="nav-ic">{n.icon}</span>
                  <span className="nav-label">{n.label}</span>
                  {route.page === n.id && <span className="nav-active"/>}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className="env-pill">
            <span className="env-dot"/>
            <div>
              <b>集团私有云</b>
              <span>llm-gw.hik.internal</span>
            </div>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="crumb-trail">
            <span className="muted">AgentHub</span>
            <span className="sep">/</span>
            <span>{NAV.find(n => n.id === route.page)?.label || '页面'}</span>
            {route.id && <><span className="sep">/</span><b>{route.id}</b></>}
          </div>
          <div className="topbar-search">
            {I.search}
            <input placeholder="跨 SKU、项目、知识库、人员搜索 …"/>
            <kbd>⌘K</kbd>
          </div>
          <div className="topbar-right">
            <button className="ic-btn" title="集团 LLM Gateway 状态">{I.spark}</button>
            <button className="ic-btn badge" title="通知">{I.bell}<span className="badge-dot">3</span></button>
            <div className="me">
              <Avatar name="陈" tone="primary"/>
              <div className="me-text">
                <b>陈思源</b>
                <span>Platform Eng · BU 平台底座</span>
              </div>
            </div>
          </div>
        </header>

        <div className="scroll">
          {route.page === 'dashboard'   && <DashboardPage   go={go}/>}
          {route.page === 'marketplace' && <MarketplacePage go={go}/>}
          {route.page === 'detail'      && <DetailPage id={route.id} go={go}/>}
          {route.page === 'approvals'   && <ApprovalsPage   go={go}/>}
          {route.page === 'mine'        && <PlaceholderPage title="我的技能" desc="我作为作者维护的 SKU、订阅的 SKU、与我项目相关的 SKU。（一阶段后扩展）"/>}
          {route.page === 'docs'        && <PlaceholderPage title="使用手册" desc="Skill 创作规范、SKU 发布流程、错误码与命名约定。（一阶段后扩展）"/>}
          {route.page === 'settings'    && <PlaceholderPage title="组织设置" desc="Managed Settings · 业务域 · 角色与审批路由 · LLM Gateway 接入。（一阶段后扩展）"/>}
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="主题"/>
        <TweakColor
          label="品牌主色"
          value={PALETTES[t.palette]['--accent']}
          options={Object.values(PALETTES).map(p => p['--accent'])}
          onChange={(v) => {
            const key = Object.keys(PALETTES).find(k => PALETTES[k]['--accent'] === v) || 'hikRed';
            setTweak('palette', key);
          }}
        />
        <TweakToggle label="深色顶栏" value={t.useDarkTopbar} onChange={v => setTweak('useDarkTopbar', v)}/>
        <TweakSection label="密度"/>
        <TweakRadio
          label="界面密度"
          value={t.density}
          options={['compact','comfortable']}
          onChange={v => setTweak('density', v)}
        />
        <TweakToggle label="侧栏显示文字" value={t.showSidebarLabels} onChange={v => setTweak('showSidebarLabels', v)}/>
      </TweaksPanel>
    </div>
  );
}

function PlaceholderPage({ title, desc }) {
  return (
    <div className="page">
      <header className="page-hero">
        <div>
          <div className="page-eyebrow">研发辅助</div>
          <h1>{title}</h1>
          <p className="page-sub">{desc}</p>
        </div>
      </header>
      <div className="placeholder">
        <div className="ph-pattern"/>
        <div className="ph-text">该模块原型占位，可在后续 sprint 中扩展。</div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
